<?php
  namespace Core;

  echo 'init Core </br>';


  class Core
  {
    public function run()
    {
      echo 'Core->run </br>';
      include 'routes.php';

      //echo __CLASS__ . " [OK]" . PHP_EOL;
      $url = str_replace(BASE_URI, '', $_SERVER['REQUEST_URI']);
      var_dump($url);
      echo '</br>';

      $info = Router::get($url);
      var_dump($info);
      echo '</br>';

      $controllerWanted = $info['controller'];
      $controllerWanted = $controllerWanted . 'Controller';
      $controllerWanted = ucfirst($controllerWanted);
      $methode = $info['action'];
      $methode = $methode . 'Action';
      echo 'le controler demander => '.$controllerWanted;
      echo '   - la methode demander => '.$methode.'</br>';
      if (isset($info['arguments'])) {
      //if le tableu contien des argument !
          echo' contients des argument</br>';
          $arguments = implode ( ',' , $info['arguments']);
          $new_controller = new $controllerWanted;
          $new_controller->$methode($arguments);
      }
      else{
        $new_controller = new $controllerWanted;
        $new_controller->$methode();
      }
      
      echo 'Core->END </br>';
    }
}
