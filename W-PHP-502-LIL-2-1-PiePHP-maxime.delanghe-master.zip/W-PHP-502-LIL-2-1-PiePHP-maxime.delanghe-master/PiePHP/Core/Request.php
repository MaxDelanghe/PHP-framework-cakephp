<?php
namespace Core;

class Request {
	public $query = [];

	public function getParams(){
        echo 'oki';
	}
}
