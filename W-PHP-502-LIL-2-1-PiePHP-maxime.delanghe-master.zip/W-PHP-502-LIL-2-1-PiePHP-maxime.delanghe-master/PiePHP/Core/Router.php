<?php
namespace Core;
echo 'init Router</br>';

Class Router {
    
    private static $routes;
    public static function connect($url, $route) {
        echo 'router->connect </br>';
        self::$routes[$url] = $route;
    }
    public static function get($url) {
        echo 'router->get </br>';
        if (isset(self::$routes[$url])) {
            echo 'router->get RETURN ->'.$routes[$url].'</br>';
            return self::$routes[$url];
        }

        else {
            $string = $url;
            $typeUrl = substr_count($string, '/');
            $argcBool = substr_count($string, '=');
            //echo "$string";
            echo "$typeUrl";
            echo "$argcBool";
            
            if ($typeUrl == 1 && $argcBool == 0) { //cas 1-> /user
                echo 'cas ->------------------1'.'</br>';

                $controller = substr($string, 1);
                if (class_exists(ucfirst($controller.'Controller'))) {
                    if (method_exists(ucfirst($controller.'Controller'), 'indexAction')) {
                        return $url = array('controller' => $controller, 'action' => 'index');
                    }
                    else{
                        return self::$routes['/error']; 
                    }
                }
                else{
                    return self::$routes['/error']; 
                }
            }
            elseif ($typeUrl == 1 && $argcBool == 2) { //cas 2-> /?c=user&a=add
                echo 'cas ->------------------2'.'</br>';

                $tab = explode('&', $string);
                $roadParam = array();
                $tempo = array();
                foreach ($tab as $key => $value) {
                  $tempo = explode('=', $value);
                  array_push($roadParam, $tempo[1]);
                }
                $controller = $roadParam[0];
                $action = $roadParam[1];
                if (class_exists(ucfirst($controller.'Controller'))) {
                    if (method_exists(ucfirst($controller.'Controller'), $action.'Action')) {
                        return $url = array('controller' => $controller, 'action' =>  $action);
                    }
                    elseif (method_exists(ucfirst($controller.'Controller'), 'indexAction')) {
                        return $url = array('controller' => $controller, 'action' => 'index');
                    }
                    else{
                        return self::$routes['/error']; 
                    }
                }
                else{
                    return self::$routes['/error']; 
                }
            }
            elseif ($typeUrl == 1 && $argcBool > 2) {//cas -> 3/?c=user&a=add&b=sdas....
                echo 'cas ->------------------3'.'</br>';

                $tab = explode('&', $string);
                $roadParam = array();
                $tempo = array();
                foreach ($tab as $key => $value) {
                  $tempo = explode('=', $value);
                  array_push($roadParam, $tempo[1]);
                }
                $controller = $roadParam[0];
                $action = $roadParam[1];
                unset($roadParam[0]);
                unset($roadParam[1]);
                $argumentsArray = array_values($roadParam);
                if (class_exists(ucfirst($controller.'Controller'))) {
                    if (method_exists(ucfirst($controller.'Controller'), $action.'Action')) {
                        return $url = array('controller' => $controller, 'action' =>  $action, 'arguments' => $argumentsArray);
                    }
                    elseif (method_exists(ucfirst($controller.'Controller'), 'indexAction')) {
                        return $url = array('controller' => $controller, 'action' => 'index');
                    }
                    else{
                        return self::$routes['/error']; 
                    }
                }
                else{
                    return self::$routes['/error']; 
                }
            }
            elseif ($typeUrl == 2 && $argcBool == 0) {//cas -> 4/user/add
                echo 'cas ->------------------4'.'</br>';

                $roadParam = explode('/', $string);
                $controller = $roadParam[1];
                if ($roadParam[1] == '') {
                    $controller = 'app';
                }
                $action = $roadParam[2];
                if (class_exists(ucfirst($controller.'Controller'))) {
                    if (method_exists(ucfirst($controller.'Controller'), $action.'Action')) {
                        return $url = array('controller' => $controller, 'action' =>  $action, 'arguments' => $argumentsArray);
                    }
                    elseif (method_exists(ucfirst($controller.'Controller'), 'indexAction')) {
                        return $url = array('controller' => $controller, 'action' => 'index');
                    }
                    else{
                        return self::$routes['/error']; 
                    }
                }
                else{
                    return self::$routes['/error']; 
                }
            }
            elseif ($typeUrl == 2 && $argcBool > 0) {//cas 5-> /user/add?frrf=sad&jour=kos.....
                echo 'cas ->------------------5'.'</br>';

                $roadParam = explode('/', $string);
                $controller = $roadParam[1];
                $position = strpos ( $roadParam[2] , '?');
                $action = substr($roadParam[2], 0, $position);

                $tab = explode('&', $string);
                $argumentsArray = array();
                $tempo = array();
                foreach ($tab as $key => $value) {
                  $tempo = explode('=', $value);
                  array_push($argumentsArray, $tempo[1]);
                }
                if (class_exists(ucfirst($controller.'Controller'))) {
                    echo $controller .'</br>';
                    echo $action .'</br>';

                    if (method_exists(ucfirst($controller.'Controller'), $action.'Action')) {
                        return $url = array('controller' => $controller, 'action' =>  $action, 'arguments' => $argumentsArray);
                    }
                    elseif (method_exists(ucfirst($controller.'Controller'), 'indexAction')) {
                        return $url = array('controller' => $controller, 'action' => 'index');
                    }
                    else{
                        return self::$routes['/error']; 
                    }
                }
                else{
                    return self::$routes['/error']; 
                }
            }
            elseif ($typeUrl > 2 && $argcBool == 0) {//cas 6-> /user/add/1/5/9...
                echo 'cas ->------------------6'.'</br>';
                $roadParam = explode('/', $string);
                $controller = $roadParam[1];
                $action = $roadParam[2];
                unset($roadParam[0]);
                unset($roadParam[1]);
                unset($roadParam[2]);
                $argumentsArray = array_values($roadParam);
                if (class_exists(ucfirst($controller.'Controller'))) {
                    if (method_exists(ucfirst($controller.'Controller'), $action.'Action')) {
                        return $url = array('controller' => $controller, 'action' =>  $action, 'arguments' => $argumentsArray);
                    }
                    elseif (method_exists(ucfirst($controller.'Controller'), 'indexAction')) {
                        return $url = array('controller' => $controller, 'action' => 'index');
                    }
                    else{
                        return self::$routes['/error']; 
                    }
                }
                else{
                    return self::$routes['/error']; 
                }
            }
        }
    }
}