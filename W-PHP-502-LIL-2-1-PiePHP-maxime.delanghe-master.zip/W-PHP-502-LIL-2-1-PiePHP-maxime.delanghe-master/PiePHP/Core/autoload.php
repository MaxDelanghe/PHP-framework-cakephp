<?php

spl_autoload_register(function ($cl) {
    echo 'in autoload START ';
    echo '--------------------';
    echo '</br>';

    $cl = explode("\\", $cl);
    foreach ($cl as $value) {
        $class = $value . '.php';
    }
    echo $class;
    echo '</br>';
    if (file_exists("Core/" . $class)) {
        require_once("Core/" . $class);
    }

    if (file_exists("src/Controller/" . $class)) {
        require_once("src/Controller/" . $class);
    }

    if (file_exists("src/Model/" . $class)) {
        require_once("src/Model/" . $class);
    }
    
    if (file_exists("src/View" . $class)) {
        require_once("src/View" . $class);
    }
    echo ' autoload END '; echo '------------------';
    echo '</br>';
});
