<?php
/*echo "<pre>Post -> ";print_r($_POST);echo "</pre>";
echo "<pre>Get -> ";print_r($_GET);echo "</pre>";
echo "<pre>Server -> ";print_r($_SERVER);echo "</pre>";*/

echo 'lauch app </br>';
define('BASE_URI', str_replace('\\','/', substr(__DIR__ , strlen($_SERVER['DOCUMENT_ROOT']))));
require_once(implode(DIRECTORY_SEPARATOR , ['Core','autoload.php']));

$app = new  Core\Core();
echo '$app = new  Core\Core() END</br>';

$app ->run();
echo '$app ->run() END</br>';
