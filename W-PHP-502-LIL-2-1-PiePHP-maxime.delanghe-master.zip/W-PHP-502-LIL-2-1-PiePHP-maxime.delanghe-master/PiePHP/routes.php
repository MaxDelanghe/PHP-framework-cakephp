<?php
use Core\Router;

echo 'START routes.php</br>';echo '--------------------';
echo '</br>';

Router::connect('/error', ['controller' => 'error', 'action' => 'error']);
Router::connect('/', ['controller'=>'app','action'=>'index']);
Router::connect('/register', ['controller'=>'user','action'=>'add']);

echo 'END routes.php';
echo '------------------------------';
echo '</br>';
