<?php

class UserController extends \Core\Controller
{
        public function addAction(){
                $this->render("register");     
                echo 'add d\'un user</br>';
        }
        public function indexAction(){
                $this->render("index");     
                echo 'index d\'un user</br>';
        }

        public function registerAction(){
                if (isset($_POST['email']) && isset($_POST['password']) && !(empty($_POST['email'])) && !(empty($_POST['password']))) {
                        echo 'creation</br>';
                        print_r($_POST);
                       // $register = new UserModel($_POST['email'], $_POST['password']);
                       // $register->save();
                        $this->render("login");

                }
                else {
                        $this->render("register");
                }
        }
        public function loginAction() {
                $this->render("login");
        }

        public function helloAction($name, $firstname, $age) { 
                $this->render("hello");
        }
}