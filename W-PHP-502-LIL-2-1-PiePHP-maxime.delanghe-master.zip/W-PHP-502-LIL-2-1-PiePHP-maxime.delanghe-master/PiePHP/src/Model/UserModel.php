<?php

class UserModel {
    private $email;
    private $password;
    private $bdd;
	
	public function __construct($email, $password)
    {
        $this->bdd = new \PDO('mysql:host=localhost;dbname=piephp;charset=utf8', 'ryu', '9108');
        $this->email = $email;
        $this->password = $password;
	}

    public function save()
    {
        $sql = "INSERT INTO user (id, email, password) VALUES (NULL, :mail, :password)";
        $result_sql = $this->bdd->prepare($sql);
        $result_sql->bindParam(':mail', $this->email);
        $result_sql->bindParam(':password', $this->password);
        $result_sql->execute();
    }
}