<h1>Page default de mon App</h1>

<img src="webroot/assets/bg.jpg">