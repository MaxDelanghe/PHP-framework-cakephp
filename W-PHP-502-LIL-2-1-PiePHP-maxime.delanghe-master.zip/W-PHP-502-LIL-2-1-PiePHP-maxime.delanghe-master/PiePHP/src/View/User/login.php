<div>
    <h2 class=''>Connexion</h2>
    <form class="" action="./index.php" method="POST">
      <label for="email">Votre email</label>
      <input type="email" name="email" value="">
      <label for="mpd">Votre mdp</label>
      <input type="password" name="mdp" value="">
      <input type="submit" value="Envoyer">
    </form>
</div>