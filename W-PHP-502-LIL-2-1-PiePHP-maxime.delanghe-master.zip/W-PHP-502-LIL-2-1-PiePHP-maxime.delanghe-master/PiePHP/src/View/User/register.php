<div>

    <a href="/PiePHP/user/register">VIIIC</a>
    <form action='/PiePHP/user/register' method='POST'>
        <h2>Inscription</h2>
        <label for='email'>Votre Email : </label>
        <input type='text' name='email' placeholder='example@free.com'/>
        <label for='password'>Mot de passe : </label>
        <input type='password' name='password' placeholder='...'/>
        <button type='submit'>Submit</button>
    </form>
</div>